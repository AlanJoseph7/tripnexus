# TripNexus

TripNexus plans trips using five Groq-backed specialist roles and a local travel-data/tool catalogue. The React client communicates with the Express API; provider credentials remain server-side.

## Run & Operate

- Use the managed **TripNexus** web service for the UI and **API Server** service for `/api` routes; the Replit router connects them.
- `pnpm --filter @workspace/api-server run test` — server unit/orchestration tests (uses a test model, no provider calls)
- `pnpm --filter @workspace/api-server run typecheck` — API server typecheck
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI contract
- `pnpm run typecheck` — check all workspace packages and artifacts
- `PORT=5000 BASE_PATH=/ pnpm run build` — typecheck and build workspace artifacts
- Required secret: `GROQ_API_KEY`; optional `GROQ_MODEL` defaults to `openai/gpt-oss-20b`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Web artifact: React, Vite, React Query, Wouter
- API: Express 5, Groq OpenAI-compatible HTTP API, Zod
- API codegen: Orval from `lib/api-spec/openapi.yaml`
- API build: esbuild ESM bundle

## Where things live

- `artifacts/tripnexus` — TripNexus web UI and styles
- `artifacts/api-server/src/trips` — Groq client, local tools, agent orchestration and run trace
- `artifacts/api-server/src/data` — bundled destinations, places, seasonal climate, demo scenarios and agent roster
- `artifacts/api-server/src/routes` — health, trip-planning, trace and PDF routes
- `lib/api-spec/openapi.yaml` — API source of truth; regenerate hooks and Zod after edits
- `docs/` — CA3-style synopsis, design, input/output, trace, demo and viva material

## Architecture decisions

- Groq is called only from the API server; store `GROQ_API_KEY` using Replit Secrets, never in browser code.
- Planning uses bounded structured model output, Zod validation, allowlisted local tools, a 15-action manager cap, an eight-tool-per-task cap, eight calls per agent per run and at most three revisions.
- Cost totals are calculated by the local budget tool; generated text explains the calculation but cannot override its numeric result.
- Weather uses bundled typical-climate patterns, not live forecasts. Distance is straight-line, and destination rates are estimates.
- Run traces are bounded, process-local memory; they expire after 24 hours and are cleared by an API restart.

## Product

Users can enter a trip brief or load a sample, request a coordinated plan, inspect itinerary/budget/weather and Critic feedback, browse the actual agent messages and trace, and export the trace or project documentation.

## Gotchas

- The trace retrieval endpoint only works while its API process retains the run; the plan response itself includes the trace for immediate export.
- Run typechecks and tests without calling `POST /api/plan-trip` during routine verification to avoid unintended model charges.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
