# Design and architecture

## System overview

```text
React/Vite client
  └── generated React Query client
        └── Express API (/api)
              ├── OpenAPI-generated Zod validation
              ├── adaptive Trip Manager
              ├── Destination, Budget, Weather and Critic agents
              ├── allowlisted local JSON-backed tools
              ├── server-only Groq chat-completions client
              └── bounded in-memory completed-run trace store
```

## Agent responsibilities

| Agent | Responsibility |
| --- | --- |
| Trip Manager | Creates a bounded task plan, assigns three specialists, receives the Critic's rejection and routes a correction. |
| Destination Agent | Selects only bundled place IDs, assembles the dated itinerary, resolves place details and estimates daily straight-line routes. |
| Budget Agent | Uses a deterministic cost calculation for the whole group and explains the result without changing its figures. |
| Weather Agent | Uses bundled typical monthly conditions and supplies date-specific recommendations and catalogued indoor alternatives. |
| Critic Agent | Independently reviews itinerary coverage, costs, routes and weather caveats and can reject a plan for a targeted revision. |

## Orchestration safeguards

- API request, local tool arguments, model output and final response are validated with Zod.
- The Manager is limited to 15 actions per run; each task can call at most eight allowlisted local tools; each agent is limited to eight Groq calls per run.
- The Critic can request a maximum of three targeted revisions.
- The server checks date coverage and supported place IDs. Budget component arithmetic is calculated and checked locally.
- Groq credentials are read only by the server. Provider request bodies and keys are not written to the trace.

## Data and trade-offs

Bundled JSON allows the application and tests to work without a separate database or external data credentials. This keeps the demonstration self-contained, but the data are estimates and are not refreshed from a live booking, mapping or weather service.

Completed traces are held in bounded process memory for up to 24 hours. This avoids persisting user travel briefs, but process restarts clear the trace retrieval endpoint.
