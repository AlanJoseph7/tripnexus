# Execution trace guide

## Event fields

Every trace event has an event ID, run ID, sequence number, timestamp, agent ID, optional sender/recipient, event type, optional action and tool name, summary, status and revision number.

## Event types

- `run_started` and `run_completed`
- `manager_action`
- `model_call` with attempt number and start/completed/failed status
- `agent_message` for manager handoffs, specialist results, Critic reviews and revision requests
- `tool_call` and `tool_result`

The event sequence is assigned when the runtime records each event. Messages are recorded separately and include sender, recipient, task, result, status and an optional critic issue ID.

## Reading the trace

1. Follow Trip Manager assignments to the Destination, Budget and Weather specialists.
2. Check `places_search`, `place_details` and `route_distance` results against the itinerary.
3. Compare the budget-tool call with the displayed component totals.
4. Read each Critic report. On rejection, find the corresponding issue ID in the Manager and specialist messages.
5. Confirm that a later review records approval or that the plan finishes as `needs_attention` after the revision limit.

## Storage and export

The plan response includes the event and message arrays. The API trace endpoint and UI JSON export expose these same captured records. Server-side retrieval is in-memory only (maximum 250 recent runs, 24-hour retention); a process restart clears it.

## Privacy

Trace summaries describe decisions and operations. Provider credentials are never included. Do not place sensitive personal information in free-form trip notes.
