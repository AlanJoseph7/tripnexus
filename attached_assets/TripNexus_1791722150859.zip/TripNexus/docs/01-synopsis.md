# TripNexus — project synopsis

## Problem

Planning a group trip means reconciling dates, interests, pace, budget, geography and weather. A single generic response can obscure trade-offs and make it difficult to see why recommendations were made.

## Aim

TripNexus turns a structured trip brief into a dated itinerary and a transparent estimate by delegating work to five specialist agent roles, then reviewing the combined draft with an independent Critic.

## Intended users

Small groups planning leisure trips in India, and students demonstrating multi-agent orchestration, tool use and agent-to-agent traceability.

## Main capabilities

- Create a trip brief or fill one of five bundled examples.
- Plan for one of eight supported Indian destinations.
- Review a day-by-day itinerary, local cost estimate and typical seasonal conditions.
- Inspect the five specialist responsibilities, messages, Critic issues, revisions and actual runtime events.
- Download the trace as JSON and the project guide as PDF.

## Scope and limits

Groq generates the agents' structured decisions and explanations through server-side structured-output requests. Tool results are validated and derived from local JSON data. Cost data are indicative, route distances are straight-line estimates, weather is typical monthly climate (not a live forecast), and the app does not book travel.
