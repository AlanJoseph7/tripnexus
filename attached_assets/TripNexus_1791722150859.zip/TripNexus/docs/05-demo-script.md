# Demonstration script

1. Open the web preview and point out the API connection, selected Groq model and server-side provider call boundary.
2. Load “A balanced Jaipur culture trip” from the sample selector.
3. Review inclusive dates, traveler count, total group budget, preferences and pace.
4. Run the planner. Note that the app performs real Groq calls, subject to the account's usage limits and pricing.
5. Inspect the itinerary. Explain that place IDs and activity costs are grounded in the bundled local catalogue.
6. Review the INR group budget calculation and identify the straight-line route estimate caveat.
7. Read the seasonal climate note. Explain that it uses typical monthly climate data, not a live forecast.
8. Open agent messages and the searchable/filterable trace. Follow the Trip Manager dispatch, tool results, Critic review and any targeted revision.
9. Export the trace JSON and download the project guide PDF.
10. Point out that plan runs require `GROQ_API_KEY` in Replit Secrets; automated tests use a fixture model or mocked HTTP and do not call Groq.
