# Input and output reference

## Trip request

`POST /api/plan-trip` accepts:

| Field | Type | Rule |
| --- | --- | --- |
| `destinationId` | string | Must match one of the eight bundled destinations. |
| `origin` | string | Optional; maximum 120 characters. |
| `startDate`, `endDate` | `YYYY-MM-DD` | Inclusive range, 1–14 days; end cannot precede start. |
| `travelers` | integer | 1–12. |
| `budgetInr` | integer | Group budget, INR 1,000–10,000,000. |
| `interests` | string array | Up to eight short preferences. |
| `activityPreferences` | string array | Up to eight activity preferences. |
| `pace` | enum | `relaxed`, `balanced`, or `packed`. |
| `notes` | string | Optional; maximum 500 characters. |

`POST /api/plan-trip` responds immediately with HTTP `202` and `{ runId, status: "queued" }`. Poll `GET /api/runs/{runId}` every 1.5 seconds. It returns `queued` or `running` until a terminal response includes either `result` or a categorized `error`.

## Plan result

A successful response contains a `runId`, approval state, Groq mode/model, normalized request, itinerary, budget assessment, seasonal weather assessment, Critic reports, agent messages, actual execution events, agent IDs and revision count.

### Itinerary

Each day has a date, theme, one or two activities and a straight-line route-distance estimate. Each activity includes its bundled place ID, category, time, duration, indicative cost, setting, area and planning rationale.

### Budget

The estimate separates accommodation, food, activities, transport and contingency. All figures are INR group estimates. Numeric components come from the deterministic local tool; model-generated explanation does not alter them.

### Weather

Each date includes a typical seasonal summary, temperature range, typical rain chance, affected itinerary items and a recommendation. These values are not a live forecast.

### Critic and trace

Critic reports include `APPROVED` or `REJECTED`, supported issues and a summary. A run may contain up to three revisions. Trace events show actual model-call attempts, tool calls/results, messages, handoffs, review decisions and completion.

## Error behavior

- `400 INVALID_TRIP_REQUEST` — invalid data or unsupported destination.
- `502 GROQ_REQUEST_FAILED` — Groq could not return a usable structured response.
- `502 GROQ_AUTH_FAILED` — Groq rejected the API key or access.
- `502 GROQ_MODEL_UNAVAILABLE` — the configured model is not available to the key.
- `503 GROQ_RATE_LIMITED` — Groq rate limits or account quota prevented completion.
- `504 GROQ_TIMEOUT` — the provider request timed out.
- `503 GROQ_NETWORK_ERROR` — the API server could not reach Groq.
- `502 PLANNING_VALIDATION_FAILED` — a generated plan failed a server-side planning check.
- `503 GROQ_NOT_CONFIGURED` — the server does not have `GROQ_API_KEY` in its secret environment.
- `503 PLANNING_CAPACITY_REACHED` — the in-memory run queue is full; retry shortly.
- `500 INTERNAL_ERROR` — an unexpected server-side failure occurred.
- `404 RUN_NOT_FOUND` — the run is unknown or expired, or the API restarted before it could be polled.
- `404 TRACE_NOT_FOUND` — the run is expired or the server process restarted.
