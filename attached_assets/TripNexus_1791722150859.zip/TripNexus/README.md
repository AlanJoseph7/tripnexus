# TripNexus

TripNexus is a multi-agent travel planner. A Trip Manager coordinates destination, budget and seasonal-weather specialists; an independent Critic can reject a draft and route focused revisions. The browser calls the TripNexus API, and only the API server calls Groq.

## Run in Replit

Replit runs the **TripNexus** web app and the **API Server** as separate managed services. Open the TripNexus preview for the website; requests under `/api` are routed to the API service.

Add `GROQ_API_KEY` in **Tools → Secrets**. The key is read only on the API server. The optional `GROQ_MODEL` setting defaults to `openai/gpt-oss-20b`; select a model enabled for your account that supports structured JSON outputs. Strict JSON-schema output is enabled for Groq's supported GPT-OSS models, while other configured models use best-effort structured output. Model availability and usage limits are controlled by Groq.

For local development, copy `.env.example` to the project-root `.env` file and add a newly created key there. The API server loads that file on startup (Node.js 24); Replit uses the server's Secrets instead. Never commit `.env` or paste a key into the app, source files, issues, or logs.

## Main features

- Eight bundled Indian destinations, local place records and five API-provided demo trips
- Inclusive-date trip requests with traveler count, INR group budget, interests, activity preferences and pace
- Five Groq-backed agent roles, strict structured output where supported, and typed/validated model output
- Budget breakdown and arithmetic checks, straight-line route estimates and bundled typical-climate estimates
- Critic decisions, targeted specialist revisions (maximum three), inter-agent messages and execution trace
- Searchable trace, JSON export and downloadable project-guide PDF
- Missing or out-of-order weather notes are reconciled by date; gaps use the bundled climate data instead of failing the full plan

## Run checks

```sh
pnpm --filter @workspace/api-spec run codegen
pnpm run typecheck
pnpm --filter @workspace/api-server run test
PORT=5000 BASE_PATH=/ pnpm run build
```

The server tests use an injected test model or mocked HTTP responses and do not make billable Groq requests. In Replit, use the managed web and API services rather than starting a second copy with a root-level dev command.

To verify a real provider run, set `GROQ_API_KEY` in Replit Secrets (or in the local `.env`), confirm the health status shows Groq configured, load a sample request, and run the planner. A completed run should include the selected Groq model and actual model-call events in its trace. This real-provider check requires an active model/key and may consume account quota.

## API

All routes use the `/api` prefix:

| Method | Route | Purpose |
| --- | --- | --- |
| GET | `/healthz` | API health, configured model and key-presence boolean |
| GET | `/agents` | Agent names and responsibilities |
| GET | `/destinations` | Supported destination catalogue |
| GET | `/demo` | Sample trip requests |
| POST | `/plan-trip` | Queue a Groq-backed planning session; returns `202` and a run ID |
| GET | `/runs/{runId}` | Poll for queued/running/completed/failed status and retrieve the result |
| GET | `/runs/{runId}/trace` | Retrieve a completed run's captured trace |
| GET | `/documentation.pdf` | Download the project guide |

The source contract is `lib/api-spec/openapi.yaml`. The React Query hooks and server Zod schemas are generated from it; regenerate them after changing API contracts.

## Estimate and storage caveats

The place and destination data are bundled JSON records. Budget numbers are approximate group estimates, not quotes. Route distance is a straight-line coordinate estimate, not road or transit routing. Weather uses typical monthly climate patterns, not a current forecast. TripNexus does not make reservations.

Run statuses, completed results and traces are held in API-process memory for up to 24 hours, capped at 250 runs. A server restart clears them; if polling returns `RUN_NOT_FOUND`, start a new plan. Export a run as JSON if you need to keep its trace.

## Project documentation

The `docs/` directory contains the project synopsis, architecture, input/output reference, execution-trace guide, demo script and viva/review guide. A pull-request template is in `.github/PULL_REQUEST_TEMPLATE.md`.
