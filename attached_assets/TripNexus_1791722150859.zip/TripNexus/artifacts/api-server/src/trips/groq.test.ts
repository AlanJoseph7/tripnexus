import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { z } from "zod";

import { GroqJsonModel } from "./groq";

function response(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

describe("Groq request recovery", () => {
  const originalFetch = globalThis.fetch;

  beforeEach(() => {
    process.env.GROQ_API_KEY = "unit-test-key";
    delete process.env.GROQ_MODEL;
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
    globalThis.fetch = originalFetch;
    delete process.env.GROQ_API_KEY;
    delete process.env.GROQ_MODEL;
  });

  it("sends a server-side chat-completion request with the configured structured schema", async () => {
    const fetchMock = vi.fn().mockResolvedValue(response(200, {
      choices: [{ message: { content: '{"ready":true}' } }],
    }));
    globalThis.fetch = fetchMock as typeof fetch;

    const pending = new GroqJsonModel().generateJson(
      "request-shape-test",
      "trip_manager",
      "Return JSON.",
      '{"request":"test"}',
      z.object({ ready: z.boolean() }),
      { type: "object", properties: { ready: { type: "boolean" } }, required: ["ready"], additionalProperties: false },
    );
    await vi.runAllTimersAsync();

    await expect(pending).resolves.toEqual({ ready: true });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toBe("https://api.groq.com/openai/v1/chat/completions");
    expect((init.headers as Record<string, string>).Authorization).toBe("Bearer unit-test-key");
    const body = JSON.parse(String(init.body));
    expect(body.model).toBe("openai/gpt-oss-20b");
    expect(body.response_format.json_schema.name).toBe("trip_manager");
    expect(body.response_format.json_schema.strict).toBe(true);
    expect(body.response_format.json_schema.schema.required).toEqual(["ready"]);
    expect(body.messages).toHaveLength(2);
  });

  it("recovers from temporary provider errors", async () => {
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(response(503, {}))
      .mockResolvedValueOnce(response(503, {}))
      .mockResolvedValueOnce(response(200, { choices: [{ message: { content: '{"ready":true}' } }] }));
    globalThis.fetch = fetchMock as typeof fetch;

    const events: Array<{ attempt: number; status: string }> = [];
    const pending = new GroqJsonModel().generateJson(
      "retry-success-test",
      "trip_manager",
      "Return JSON.",
      "{}",
      z.object({ ready: z.boolean() }),
      { type: "object" },
      (event) => events.push(event),
    );
    await vi.runAllTimersAsync();

    await expect(pending).resolves.toEqual({ ready: true });
    expect(fetchMock).toHaveBeenCalledTimes(3);
    expect(events.filter((event) => event.status === "started").map((event) => event.attempt)).toEqual([1, 2, 3]);
    expect(events.at(-1)).toEqual({ attempt: 3, status: "completed" });
  });

  it("returns a clear authentication failure without retrying", async () => {
    const fetchMock = vi.fn().mockResolvedValue(response(401, { error: "private provider body" }));
    globalThis.fetch = fetchMock as typeof fetch;

    await expect(new GroqJsonModel().generateJson(
      "auth-failure-test",
      "trip_manager",
      "Return JSON.",
      "{}",
      z.object({ ready: z.boolean() }),
      { type: "object" },
    )).rejects.toMatchObject({
      name: "GroqRequestError",
      statusCode: 502,
      code: "GROQ_AUTH_FAILED",
      message: expect.stringContaining("GROQ_API_KEY"),
    });
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("identifies an unavailable model and does not retry", async () => {
    process.env.GROQ_MODEL = "not-a-model";
    const fetchMock = vi.fn().mockResolvedValue(response(404, {}));
    globalThis.fetch = fetchMock as typeof fetch;

    await expect(new GroqJsonModel().generateJson(
      "model-failure-test",
      "trip_manager",
      "Return JSON.",
      "{}",
      z.object({ ready: z.boolean() }),
      { type: "object" },
    )).rejects.toMatchObject({
      name: "GroqRequestError",
      code: "GROQ_MODEL_UNAVAILABLE",
      message: expect.stringContaining("not-a-model"),
    });
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("does not make a request when the API key is missing", async () => {
    delete process.env.GROQ_API_KEY;
    const fetchMock = vi.fn();
    globalThis.fetch = fetchMock as typeof fetch;

    await expect(new GroqJsonModel().generateJson(
      "missing-key-test",
      "trip_manager",
      "Return JSON.",
      "{}",
      z.object({ ready: z.boolean() }),
      { type: "object" },
    )).rejects.toMatchObject({ name: "GroqNotConfiguredError" });
    expect(fetchMock).not.toHaveBeenCalled();
  });
});
